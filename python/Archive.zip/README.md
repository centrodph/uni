

-  **mod_4_ej_1** Calcular el sueldo de una persona, conociendo la cantidad de horas que trabaja en el mes y el valor de la hora. 


-  **mod_4_ej_2** Calcular el importe que debe pagar una persona compra una heladera
de pesos X y por pagar en efectivo le hacen el 10% de descuento ¿Cuánto
abona?



-  **mod_4_ej_3**  Convertir longitudes de millas a Km. y de pulgadas a cm., si:
1 milla = 1.60935 Km.
1 pulgada = 2.534 cm

-  **mod_4_ej_4**  Hallar la longitud de la hipotenusa de un triángulo dada la medida de
sus catetos

-  **mod_4_ej_5**  Ingresar un número de tres cifras y mostrar el segundo dígito. 

-  **mod_4_ej_6**  Ingresar un número. Si es positivo, calcular su raíz cuadrada, si es
negativo mostrar su cuadrado y si es cero mostrar “Error. Ha ingresado un valor
nulo”.


-  **mod_4_actividad_1**   Ingresar dos números y mostrar con el mensaje correspondiente:

1. La suma.
2. La diferencia.
3. El producto.
4. El resultado de elevar el primero al segundo.

-  **mod_4_ej_7**  Ingresar las edades de dos personas. Si una de ellas es mayor de edad
y la otra menor de edad, calcular y mostrar su promedio. En caso contrario
mostrar las dos edades.


-  **mod_4_ej_15**  Ingresar la medida de un ángulo y determinar si es agudo, obtuso, recto,
nulo o llano. Si el valor ingresado es mayor a 180º mostrar la leyenda “ángulo
no válido” e ingresar un nuevo valor