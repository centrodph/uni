print("""

Ingresar un número de tres cifras y mostrar el segundo dígito. 

""")

numero = int(input("Ingresar un número de tres cifras: "))

print()

print("El segundo digito es: %s" %(str(numero)[1]))
