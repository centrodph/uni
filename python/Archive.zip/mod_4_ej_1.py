print()
print("Calcular el sueldo de una persona, conociendo la cantidad de horas que trabaja en el mes y el valor de la hora. ")
print()

cantidad_horas = float(input("Ingrese cantidad de horas: "))
valor_hora = float(input("Ingrese el valor de hora: "))

print()

print("El sueldo sera $%s" % (cantidad_horas * valor_hora))
