print("Hello world")
print(4 + 2)

# read a input from keyword

num_1 = float(input("Ingrese un numero: ")) 
num_2 = float(input("Ingrese otro numero: "))

suma = num_1 + num_2

print("el resultado es: ", suma)

"""

Comentarios 
de varias
lineas

"""